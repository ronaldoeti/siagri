SET SQL DIALECT 3;

CREATE TABLE DISTRIBUIDOR (
    ID_DISTRIBUIDOR    INTEGER NOT NULL,
    NOME_DISTRIBUIDOR  VARCHAR(100) NOT NULL,
    CNPJ_DISTRIBUIDOR  VARCHAR(100) NOT NULL
);

ALTER TABLE DISTRIBUIDOR ADD CONSTRAINT PK_DISTRIBUIDOR PRIMARY KEY (ID_DISTRIBUIDOR);


/******************************************************************************/
/***                                 Tables                                 ***/
/******************************************************************************/


CREATE TABLE LIMITECREDITO (
    ID_LIMITECREDITO INTEGER NOT NULL,
    ID_PRODUTOR INTEGER NOT NULL,
    ID_DISTRIBUIDOR INTEGER NOT NULL,
    VALOR_LIMITECREDITO NUMERIC(15,2) NOT NULL);

ALTER TABLE LIMITECREDITO
ADD CONSTRAINT PK_LIMITECREDITO
PRIMARY KEY (ID_LIMITECREDITO);

CREATE SEQUENCE GEN_LIMITECREDITO_ID;


ALTER TABLE LIMITECREDITO
ADD CONSTRAINT FK_LIMITECREDITO_1
FOREIGN KEY (ID_PRODUTOR)
REFERENCES PRODUTOR(ID_PRODUTOR);

ALTER TABLE LIMITECREDITO
ADD CONSTRAINT FK_LIMITECREDITO_2
FOREIGN KEY (ID_DISTRIBUIDOR)
REFERENCES DISTRIBUIDOR(ID_DISTRIBUIDOR);




/******************************************************************************/
/***                                 Tables                                 ***/
/******************************************************************************/



CREATE TABLE NEGOCIACAO (
    ID_NEGOCIACAO INTEGER NOT NULL,
    ID_PRODUTOR INTEGER NOT NULL,
    ID_DISTRIBUIDOR INTEGER NOT NULL,
    ESTATUS CHAR(1) NOT NULL,
    DATA_CADASTRO DATE NOT NULL,
    DATA_APROVACAO DATE,
    DATA_CONCLUSAO DATE,
    DATA_CANCELAMENTO DATE,
    VALOR_TOTAL FLOAT NOT NULL);

ALTER TABLE NEGOCIACAO
ADD CONSTRAINT PK_NEGOCIACAO
PRIMARY KEY (ID_NEGOCIACAO);

CREATE SEQUENCE GEN_NEGOCIACAO_ID;


ALTER TABLE NEGOCIACAO
ADD CONSTRAINT FK_NEGOCIACAO_1
FOREIGN KEY (ID_PRODUTOR)
REFERENCES PRODUTOR(ID_PRODUTOR);

ALTER TABLE NEGOCIACAO
ADD CONSTRAINT FK_NEGOCIACAO_2
FOREIGN KEY (ID_DISTRIBUIDOR)
REFERENCES DISTRIBUIDOR(ID_DISTRIBUIDOR);




/******************************************************************************/
/***                                 Tables                                 ***/
/******************************************************************************/

CREATE TABLE NEGOCIACAO_ITEM (
    ID_NEGOCIACAO INTEGER NOT NULL,
    ID_SEQ INTEGER NOT NULL,
    ID_PRODUTO INTEGER NOT NULL,
    QTDE_ITEM FLOAT NOT NULL,
    SUBTOTAL_ITEM FLOAT NOT NULL);

ALTER TABLE NEGOCIACAO_ITEM
ADD CONSTRAINT PK_NEGOCIACAO_ITEM
PRIMARY KEY (ID_NEGOCIACAO,ID_SEQ);

CREATE SEQUENCE GEN_NEGOCIACAO_ITEM_ID;

ALTER TABLE NEGOCIACAO_ITEM
ADD CONSTRAINT FK_NEGOCIACAO_ITEM_1
FOREIGN KEY (ID_PRODUTO)
REFERENCES PRODUTO(ID_PRODUTO);







/******************************************************************************/
/***                                 Tables                                 ***/
/******************************************************************************/


CREATE TABLE PRODUTO (
    ID_PRODUTO INTEGER NOT NULL,
    NOME_PRODUTO VARCHAR(150) NOT NULL,
    PRECO_PRODUTO NUMERIC(15,2) NOT NULL);

ALTER TABLE PRODUTO
ADD CONSTRAINT PK_PRODUTO
PRIMARY KEY (ID_PRODUTO);

CREATE SEQUENCE GEN_PRODUTO_ID;



/******************************************************************************/
/***                                 Tables                                 ***/
/******************************************************************************/

CREATE TABLE PRODUTOR (
    ID_PRODUTOR INTEGER NOT NULL,
    NOME_PRODUTOR VARCHAR(150) NOT NULL,
    ESTATUS_PRODUTOR CHAR(1) NOT NULL,
    CPFCNPJ_PRODUTOR  VARCHAR(14) NOT NULL);


ALTER TABLE PRODUTOR ADD CONSTRAINT PK_PRODUTOR PRIMARY KEY (ID_PRODUTOR);

CREATE SEQUENCE GEN_PRODUTOR_ID;


